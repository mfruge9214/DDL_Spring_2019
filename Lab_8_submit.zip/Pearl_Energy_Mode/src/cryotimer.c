#include "cryotimer.h"



/*-----------------
 * void Cryotimer_init()
 * 	- This function initializes the cryotimer
 * 	Args: None
 * 	Returns: None
 */

void Cryotimer_init()
{
	/* Declare init struct */
	CRYOTIMER_Init_TypeDef cryo_init;
	/* Set initilization to desired configuration */
	cryo_init.enable = false;
	cryo_init.debugRun = false;
	cryo_init.em4Wakeup = true;
	cryo_init.osc = cryotimerOscULFRCO;
	cryo_init.period = cryotimerPeriod_1k;
	cryo_init.presc = cryotimerPresc_1;

	/* Initialize cryotimer */
	CRYOTIMER_Init(&cryo_init);

	/* Enable interrupts when the period is reached*/
	CRYOTIMER->IEN |= CRYOTIMER_IEN_PERIOD;
	NVIC_EnableIRQ(CRYOTIMER_IRQn);
}


/*-----------------------
 * void CRYOTIMER_IRQHandler()
 * 	- This function records the events triggered by the Cryotimer
 * 	Args: None
 * 	Returns: None
 */

void CRYOTIMER_IRQHandler()
{
	CORE_ATOMIC_IRQ_DISABLE();
	CRYOTIMER->IFC |= CRYOTIMER_IF_PERIOD;
	/* Dont need to get the interrupt flag because there is only one interrupt */
	event_trig |= CRYOTIMER_EVENT_MASK;
	/* Re-Enable Interupts */
	CORE_ATOMIC_IRQ_ENABLE();
}
