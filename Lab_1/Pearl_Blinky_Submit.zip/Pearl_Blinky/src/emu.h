// Include Files
#include "em_emu.h"
#include <stdbool.h>
#include <em_core.h>




// Global Variables



//Function Prototypes
void blockSleepMode(uint8_t);
void unblockSleepMode(uint8_t);
void sleep(void);
