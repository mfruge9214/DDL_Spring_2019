/* Includes */
#include "LEUART.h"
#include "main.h"

/* Function Implementations */

/*---------------------------
 * void leuart0_init()
 * Initializes LEUART0 Peripheral
 * Args: None
 * Returns: None
 ----------------------------*/
void leuart0_init(void){
	LEUART_Init_TypeDef leuart_init;

	/* Set the LEUART init values and initialize the LEUART0*/
	leuart_init.enable= false; // Enable LEUART after full initialization
	leuart_init.refFreq= 0;		// Use clock tree freq
	leuart_init.baudrate= 9600;	// Use standard Baud
	leuart_init.databits= leuartDatabits8;	// 8 data bits
	leuart_init.parity= leuartNoParity;		// No parity
	leuart_init.stopbits=leuartStopbits1;	// 1 stop bit

	LEUART_Init(LEUART0, &leuart_init);

	while(LEUART0->SYNCBUSY);
	/* Route the pins for the LEUART0 to output to the pins on the board */
	LEUART0->ROUTELOC0=LEUART_ROUTELOC0_RXLOC_LOC18 | LEUART_ROUTELOC0_TXLOC_LOC18;
	LEUART0->ROUTEPEN= LEUART_ROUTEPEN_RXPEN | LEUART_ROUTEPEN_TXPEN;

	/* Set commands for data receive */

	LEUART0->STARTFRAME= '?';
	LEUART0->SIGFRAME = '#';
	LEUART0->CMD |= LEUART_CMD_RXBLOCKEN;
	LEUART0->CTRL |= LEUART_CTRL_SFUBRX;
	while(LEUART0->SYNCBUSY);
	// Enable interrupts from startframe and sigframe
	LEUART0->IEN |= LEUART_IEN_SIGF;
//	LEUART0->IEN |= LEUART_IEN_STARTF;
	LEUART0->CTRL |= LEUART_CTRL_RXDMAWU | LEUART_CTRL_TXDMAWU;
	while(LEUART0->SYNCBUSY);

	NVIC_EnableIRQ(LEUART0_IRQn);
}


/*------------------------------
 * void transmit_Byte(char byte)
 * - Puts byte into LEUART->TXDATA buffer
 * Args:
 * 		byte: Byte to transmit
 * Returns: None
 ------------------------------*/
void transmit_Byte(char byte){
	while(LEUART0->SYNCBUSY);
	if(byte != NULL)
	{
		LEUART0->TXDATA= byte;
	}
	else return;
}

/*------------------------------
 * char receive_Byte()
 * - Takes a byte out of the LEUART0->RXDATA buffer
 * Args: None
 * Returns: A single byte as a char, taken out of the RXDATA buffer
 -------------------------------*/

char receive_Byte(){
	while(LEUART0->SYNCBUSY);
	return LEUART0->RXDATA;
}


/*-------------------------------
 * void LEUART0_IRQHandler()
 * - Interrupt handler for LEUART0
 * 	- Sets scheduler events in main for processor to work on
 * Args: None
 * Returns: None
 */

void LEUART0_IRQHandler(){
	unsigned int int_flag;
	int_flag=LEUART0->IF & LEUART0->IEN;
	LEUART0->IFC=int_flag;

	CORE_ATOMIC_IRQ_DISABLE();

	if(int_flag & LEUART_IF_TXC)
	{
		event_trig |= TXC_EVENT_MASK;
	}

	if(int_flag & LEUART_IF_SIGF)
	{
		event_trig |= SIGF_EVENT_MASK;
		LEUART0->IFC |= LEUART_IFC_SIGF;
	}
	CORE_ATOMIC_IRQ_ENABLE();
}


/*---------------------------
 * void Temp_to_ASCII(float temp)
 * 	- This function converts the temperature calculated to ASCII characters
 * 	Args: float temp
 * 		- The temperature retreived from the SI7021
 * 	Returns: None, but this function edits a global array Bluetooth_CMD
 */

void Temp_to_ASCII(float temp)
{
	int j=0;
	int i=0;
	int temp_int;
	int integer_places=1;
	int working;
	int num_zeros=3;
//	Assign the + or - to global variable
	if(temp>0)
	{
		Bluetooth_CMD[i]=0x2B;
	}
	else{
		Bluetooth_CMD[i]=0x2D;
		temp= temp * -1;
	}
	i++;

//	Figure out how many digits go in front of the decimal
	while(integer_places<temp)
	{
		integer_places=integer_places*10;
		num_zeros--;
	}
	// Fill in the leading zeros of the number we need to send
	for(j=0; j<num_zeros; j++)
	{
		Bluetooth_CMD[i+j]=0x30;
	}
//	Keep index continuous so we don't overwrite characters
	i=i+j;
//	Num_zeeros is only equal to 3 if the absolute value of the temp is less than 1
//	Handle special case of -1<temp<1
	if(num_zeros==3)
	{
		Bluetooth_CMD[i]=0x2E;
		i++;
	}
	//	Get tenths place resolution
	temp_int= temp*10;

	while(integer_places>0)
	{
//		Get the integer we need to send
		working=temp_int/integer_places;
//		Convert to ascii
		working += 0x30;
//		Add to String to send
		Bluetooth_CMD[i]=working;
		i++;
//		Get next digit
		temp_int=temp_int%integer_places;
		integer_places= integer_places/10;
		// After we put in the 1's place, insert a decimal
		if(integer_places==1)
		{
			Bluetooth_CMD[i]='.';
			i++;
		}
	}
	if(Celcius)
	{
		Bluetooth_CMD[i++]='C';
	}
	else{
		Bluetooth_CMD[i++]= 'F';
	}
	Bluetooth_CMD[i]='\0';
	return;
}

/*-----------------------
 *  void parse_Command(char* CMD)
 *   - This function ensures that the data received from the BLE module is formatted correctly to change the command
 *   Args: char* CMD
 *   	- CMD points to the global array filled by the LDMA
 *   Returns: None
 *   	- Changes global variable Celcius to indicate whether the temperature is in F or C
 */
void parse_Command(char* CMD)
{
//	Assume false
//	Format_Command_Valid = false;
	if(CMD[0] != '?')
	{
		return;
	}
	if((CMD[1] != 'd') && (CMD[1] != 'D'))
	{
		return;
	}
	if(CMD[3]!= '#')
	{
		return;
	}
//	Frame_Received = true;

	if(CMD[2] == 'c' || CMD[2] == 'C')
	{
		Celcius = true;
	}
	else if(CMD[2] == 'f' || CMD[2] == 'F')
	{
		Celcius = false;
	}
	else
	{
		return;
	}
	// If it gets here, the command is valid
	Format_Command_Valid = true;
	return;
}
