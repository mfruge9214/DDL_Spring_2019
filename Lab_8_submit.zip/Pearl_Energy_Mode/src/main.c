/***************************************************************************//**
 * @file
 * @brief Simple LED Blink Demo for SLSTK3402A
 *******************************************************************************
 * # License
 * <b>Copyright 2018 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/


#include "main.h"
#include "bsp.h"
#include "gpio.h"
#include "cmu.h"
#include "letimer.h"
#include "i2c.h"
#include "sleep_routines.h"
#include "LEUART.h"
#include "si7021.h"
#include "LDMA.h"
#include "cryotimer.h"
#include "capsense.h"


/* For lab 8:
 * 		Use capacitive touch sensor as a toggle switch
 * 		- Once a touch is registered, enable/disable the temp readings
 * 			- Only register one touch, and wait until a non touch event to count another
 * 			- When disabled:
 * 				- Turn off LETIMER, SENSOR_ENABLE, Stop sending data
 * 			- When re-enabled:
 * 				- Start LETIMER at count = 0;
 *
 */


int main(void)
{
  /* Initialize Global variables */
  event_trig=0;
  Format_Command_Valid = false;

  /* Initialize Celcius as true by default */
  Celcius = true;

  /* Declare local vars */
  bool prevTouch = false;
  bool currTouch;
  int prevState = STATE_ENABLED;
  float Degrees;


  Sleep_Block_Mode(EM4); 	// set lowest energy mode for the system

  EMU_DCDCInit_TypeDef dcdcInit = EMU_DCDCINIT_DEFAULT;
  CMU_HFXOInit_TypeDef hfxoInit = CMU_HFXOINIT_DEFAULT;

  /* Chip errata */
  CHIP_Init();

  /* Init DCDC regulator and HFXO with kit specific parameters */
  /* Initialize DCDC. Always start in low-noise mode. */
  EMU_EM23Init_TypeDef em23Init = EMU_EM23INIT_DEFAULT;
  EMU_DCDCInit(&dcdcInit);
  em23Init.vScaleEM23Voltage = emuVScaleEM23_LowPower;
  EMU_EM23Init(&em23Init);
  CMU_HFXOInit(&hfxoInit);

  /* Switch HFCLK to HFXO and disable HFRCO */
  CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFXO);
  CMU_OscillatorEnable(cmuOsc_HFRCO, false, false);

  /* Initialize clocks */
  cmu_init();

  /* Initialize GPIO */
  gpio_init();

  /* Initialize LETIMER0 */
  letimer0_init();

//   Initialize i2c0
  i2c0_init();

  /* Initialize LEUART */
  leuart0_init();

  /* Initialize LDMA */
  LDMA0_init();

  /* Initialize Cryotimer */
  Cryotimer_init();

  /* Initialize Capacitive Sensor */
  CAPSENSE_Init();

  /* Turn on Initialize Peripherals */
  LETIMER_Enable(LETIMER0, true);
  I2C_Enable(I2C0, true);
  LEUART_Enable(LEUART0, leuartEnable);
  CRYOTIMER_Enable(true);


  while(LEUART0->SYNCBUSY);


  /* Enable interrupts after chip has been configured */
  CORE_ATOMIC_IRQ_ENABLE();

//  Put CPU to sleep until interrupt
  Enter_Sleep();

  while (1) {
	  if(!event_trig){
		  Enter_Sleep();
	  }

	  if(event_trig & LDMA_TX_DONE_EVENT_MASK)
	  {
		  event_trig &= ~(LDMA_TX_DONE_EVENT_MASK);
		  // Enable TXC to know when the LEUART transfer is done
		  LEUART0->IEN |= LEUART_IF_TXC;
	  }

	  /* Occurs once every second, controls taking a measurement of the capsense */
	  if(event_trig & CRYOTIMER_EVENT_MASK)
	  {
		  event_trig &= ~(CRYOTIMER_EVENT_MASK);
		  CRYOTIMER->CTRL &= ~CRYOTIMER_CTRL_EN;
		  // Take measurement of capsense
		  CAPSENSE_Sense();
		  currTouch = CAPSENSE_getPressed(BUTTON0_CHANNEL);

		  /* If the state of the touch changed and If the button is being pressed*/
		  if(currTouch && !prevTouch)
		  {
			  /* If the functions were disabled, enable them */
			  if(prevState == STATE_DISABLED)
			  {
//				  GPIO_PinModeSet(LED0_port, LED0_pin, gpioModePushPull, LED0_default);

				  /* Clear the stop bit from the CMD register */
				  LETIMER0->CMD &= ~(LETIMER_CMD_STOP);

				  /* Clear the count register */
				  LETIMER0->CNT = 0;

				  /* Start the timer again */
				  LETIMER0->CMD |= LETIMER_CMD_START;

				  prevState = STATE_ENABLED;
			  }

			  /* If the functions were enabled, disable them */
			  else if(prevState == STATE_ENABLED)
			  {
//				  GPIO_PinModeSet(LED0_port, LED0_pin, gpioModePushPull, true);

				  /* Disable LETIMER */
				  LETIMER0->CMD |= LETIMER_CMD_STOP;

				  /* Disable SENSOR_ENABLE */
				  GPIO_PinModeSet(SENSOR_ENABLE_PORT, SENSOR_ENABLE_PIN, gpioModePushPull, false);

				  prevState = STATE_DISABLED;
			  }
		  }

		  prevTouch = currTouch;
		  CRYOTIMER->CTRL |= CRYOTIMER_CTRL_EN;
	  }

	  /* Transmission complete, block EM4 and disable DMA to work in Low Energy Mode*/
	  if(event_trig & TXC_EVENT_MASK)
	  {
		  LEUART0->IEN &= ~(LEUART_IEN_TXC);
		  event_trig &= ~(TXC_EVENT_MASK);
		  Sleep_UnBlock_Mode(EM3);
		  LEUART0->CTRL &= ~(LEUART_CTRL_TXDMAWU);
	  }

	  /* Stop Receiving bytes and parse the command that was received */
	  if(event_trig & SIGF_EVENT_MASK)
	  {
		  event_trig &= ~(SIGF_EVENT_MASK);
		  LEUART0->CMD |= LEUART_CMD_RXBLOCKEN;

		  /* Wait for sync */
		  while(LEUART0->SYNCBUSY);

		  /* Parse the command */
		  parse_Command(Data_Received);

		  /* Start the RX transfer */
		  LDMA_StartTransfer(LDMA_RX_CHANNEL, &ldma_xfer_RX, &ldma_descriptor_RX);
	  }


	  /* Measure Temp and convert to ASCII to send*/
	  if(event_trig & COMP1_EVENT_MASK){
		  event_trig &= ~(COMP1_EVENT_MASK);

		  /* Turn off Low Power Management */
		  LPM_Enable();

		  /* Take Measurement from SI7021 */
		  take_Measurement();

		  /* Format the data */
		  Degrees=convert_temp(save_data);


		  LPM_Disable();
		  Temp_to_ASCII(Degrees);

		  // Configure the LEUART to support DMA down to EM2
		  LEUART0->CTRL |= LEUART_CTRL_TXDMAWU;

		  // Block the system from going into EM3 until all data has been transmitted (TXC goes high)
		  Sleep_Block_Mode(EM3);

		  // Start DMA transfer after the temperature has been converted to ASCII
		  LDMA_StartTransfer(LDMA_TX_CHANNEL, &ldma_xfer_TX, &ldma_descriptor_TX);
	  }
  	}
 }
